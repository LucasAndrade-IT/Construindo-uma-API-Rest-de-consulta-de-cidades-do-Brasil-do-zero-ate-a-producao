package fors;

public class For {

  public static void main(String[] args) {

    for (int i = 0; i <= 10; i = i + 1) {
      System.out.println("I=" + i);
    }

    for (int x = 0; x <= 5; x++)
      System.out.println("X=" + x);
    
  }

}
