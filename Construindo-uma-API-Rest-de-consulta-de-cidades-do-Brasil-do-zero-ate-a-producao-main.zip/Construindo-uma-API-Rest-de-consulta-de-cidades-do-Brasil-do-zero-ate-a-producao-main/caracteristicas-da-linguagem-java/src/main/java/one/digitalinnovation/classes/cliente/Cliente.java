package one.digitalinnovation.classes.cliente;

import one.digitalinnovation.classes.pessoa.Pessoa;

public class Cliente extends Pessoa {

    public Cliente(final Integer idade) {
        super(idade);
    }
}
